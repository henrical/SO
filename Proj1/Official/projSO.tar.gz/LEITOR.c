#include<stdio.h>

int main(){
  
  printf("%d\n", ReadFromFile());
  
  return 0;
}